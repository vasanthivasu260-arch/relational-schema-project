-- Negative SQL tests (PostgreSQL)
-- Run after schema.sql and seed_data.sql.
-- Each statement is expected to FAIL. Run one at a time.

-- Test 1: duplicate student email should fail UNIQUE constraint
INSERT INTO students (full_name, email, department_id)
VALUES ('Duplicate Email', 'asha@example.com', 2);

-- Test 2: invalid department foreign key should fail
INSERT INTO students (full_name, email, department_id)
VALUES ('Orphan Student', 'orphan@example.com', 9999);

-- Test 3: invalid credits should fail CHECK constraint
INSERT INTO courses (course_name, credits, department_id, instructor_id)
VALUES ('Invalid Credits Course', 10, 2, 1);

-- Test 4: invalid enrollment status should fail CHECK constraint
INSERT INTO enrollments (student_id, course_id, status)
VALUES (2, 1, 'Maybe');

-- Test 5: negative payment amount should fail CHECK constraint
INSERT INTO payments (enrollment_id, amount, payment_status)
VALUES (2, -10.00, 'Pending');

-- Cascading-delete demonstration (run separately only if you want to test it):
-- DELETE FROM students WHERE student_id = 1;
-- Enrollments and linked payments for that student should be deleted.
