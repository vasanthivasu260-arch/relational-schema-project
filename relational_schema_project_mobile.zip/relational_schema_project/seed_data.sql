-- Sample seed data for the relational schema
INSERT INTO departments (department_name) VALUES
('Computer Science'), ('Artificial Intelligence'), ('Information Technology');

INSERT INTO students (full_name, email, department_id) VALUES
('Asha Rao', 'asha@example.com', 2),
('Kiran Kumar', 'kiran@example.com', 1),
('Meera Devi', 'meera@example.com', 3),
('Rahul Reddy', 'rahul@example.com', 2);

INSERT INTO instructors (full_name, email, department_id) VALUES
('Dr. Priya Sharma', 'priya.sharma@example.com', 2),
('Prof. Arun Das', 'arun.das@example.com', 1),
('Dr. Neha Iyer', 'neha.iyer@example.com', 3);

INSERT INTO courses (course_name, credits, department_id, instructor_id) VALUES
('Introduction to Python', 3, 2, 1),
('Database Systems', 4, 1, 2),
('Data Analytics', 3, 3, 3),
('Machine Learning Basics', 4, 2, 1);

INSERT INTO enrollments (student_id, course_id, enrollment_date, status) VALUES
(1, 1, '2026-09-01', 'Enrolled'),
(1, 4, '2026-09-02', 'Enrolled'),
(2, 2, '2026-09-03', 'Completed'),
(3, 3, '2026-09-04', 'Enrolled'),
(4, 1, '2026-09-05', 'Withdrawn');

INSERT INTO payments (enrollment_id, amount, payment_status, paid_on) VALUES
(1, 1500.00, 'Paid', '2026-09-01'),
(2, 1800.00, 'Pending', NULL),
(3, 2000.00, 'Paid', '2026-09-03'),
(4, 1200.00, 'Pending', NULL),
(5, 1500.00, 'Refunded', NULL);
